<?php
if (
  !empty($_POST['id_sidang']) AND
  !empty($_POST['id_jadwal']) AND
  !empty($_POST['n_1']) AND
  !empty($_POST['n_2']) AND
  !empty($_POST['n_3']) AND
  !empty($_POST['n_4']) AND
  !empty($_POST['n_5']) AND
  !empty($_POST['n_6']) AND
  !empty($_POST['n_total'])
) {
$id_sidang = $_POST['id_sidang'];
$id_jadwal = $_POST['id_jadwal'];
$n_1 = $_POST['n_1'];
$n_2 = $_POST['n_2'];
$n_3 = $_POST['n_3'];
$n_4 = $_POST['n_4'];
$n_5 = $_POST['n_5'];
$n_6 = $_POST['n_6'];
$n_total = $_POST['n_total'];
$catatan_penguji = $_POST['catatan_penguji'];
}
$tipe = $_GET['ts'];
if ($tipe == "kp") {

        $queryupdate_surat = "UPDATE sidang_kp_detail SET
        n_1 = '$n_1',
        n_2 = '$n_2',
        n_3 = '$n_3',
        n_4 = '$n_4',
        n_5 = '$n_5',
        n_6 = '$n_6',
        n_total = '$n_total',
        catatan_penguji = '$catatan_penguji'
        WHERE id_sidang_kp = '$id_sidang' AND id_dosen_penguji = '$_SESSION[id]'
        ";
        $sqlupdate_surat = $mysqli->query($queryupdate_surat);
        $query_sel = "SELECT * FROM sidang_ta_detail WHERE id_sidang_ta = '$id_sidang'";
        $sql_sel = $mysqli->query($query_sel);
        foreach ($sql_sel as $key => $value) {
          echo $key;
        }/*
        if ($sqlupdate_surat) {
          ?>
            <script>
              alert('Data Berhasil Disimpan!');
              window.location.href="?p=TA_kelola_nilai_sidang&id=<?php echo $id_sidang; ?>";
            </script>
          <?php
        }


        else{
          ?>
            <script>
              alert('Mohon masukkan data dengan benar!');
              window.location.href="?p=TA_kelola_nilai_sidang&id=<?php echo $id_sidang; ?>";
            </script>
          <?php
        }*/
}
elseif ($tipe == "ta") {

        $queryupdate_surat = "UPDATE sidang_ta_detail SET
        n_1 = '$n_1',
        n_2 = '$n_2',
        n_3 = '$n_3',
        n_4 = '$n_4',
        n_5 = '$n_5',
        n_6 = '$n_6',
        n_total = '$n_total',
        catatan_penguji = '$catatan_penguji'
        WHERE id_sidang_ta = '$id_sidang' AND id_dosen_penguji = '$_SESSION[id]'
        ";
        $sqlupdate_surat = $mysqli->query($queryupdate_surat);
        $query_sel = "SELECT * FROM sidang_ta_detail WHERE id_sidang_ta = '$id_sidang'";
        $sql_sel = $mysqli->query($query_sel);
        foreach ($sql_sel as $key => $value) {
          if ($key == 0) {
            if ($value['n_total'] != '') {
              $n1 = $value['n_total'];
            }
            else {
              $n1 = 0;
            }
          }
          if ($key == 1) {
            if ($value['n_total'] != '') {
              $n2 = $value['n_total'];
            }
            else {
              $n2 = 0;
            }
          }
          if ($key == 2) {
            if ($value['n_total'] != '') {
              $n3 = $value['n_total'];
            }
            else {
              $n3 = 0;
            }
          }
        }
          $n_sidang = ($n1+$n2+$n3)/3;
          echo $n_sidang;
          $query_up = "UPDATE sidang_ta SET n_akhir = '$n_sidang' WHERE id_sidang_ta = '$id_sidang'";
          $sql_up = $mysqli->query($query_up);

        if ($sqlupdate_surat AND $sql_up) {
          ?>
            <script>
              alert('Data Berhasil Disimpan!');
              window.location.href="?p=TA_kelola_nilai_sidang&id=<?php echo $id_sidang; ?>";
            </script>
          <?php
        }


        else{
          ?>
            <script>
              alert('Mohon masukkan data dengan benar!');
              window.location.href="?p=TA_kelola_nilai_sidang&id=<?php echo $id_sidang; ?>";
            </script>
          <?php
        }
}
  else {
    ?>
    <script>
    alert('Data TIDAK Berhasil Disimpan!');
    window.location.href="?p=profil";
    </script>
    <?php
  }




?>
